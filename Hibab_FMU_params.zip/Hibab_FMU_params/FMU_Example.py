from fmpy import read_model_description
import pickle
import os

## you have to install fmpy - google should help you with the command

## name simulation parameters
fmu_filename = 'Bibliothek_Simulationswerkzeug_Modelle_Waerme.fmu'

## create saving root for pickle
save_root = os.path.join(os.getcwd(), 'Params_fmu.pk')

# read the model description
model_description = read_model_description(fmu_filename)

# collect the value references / the names are connected to a certain number
vrs = {}
for variable in model_description.modelVariables:
    vrs[variable.name] = variable.valueReference

# find parameters that need to be set
idents = ['__ps__', '__ct1ds__', '__ctt__']

# put all parameters with ident in a list
list_param_set = []

for key in vrs:
    for ident in idents:
        if ident in key:
            list_param_set.append(key)

# save the list as pickle
with open(save_root, 'wb') as list_params:
    pickle.dump(list_param_set, list_params)

# # upload pickles
# with open(save_root, 'rb') as list_params:
#     list_param_set = pickle.load(list_params)